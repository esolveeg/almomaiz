<?php $__env->startSection('title', $title); ?>


<?php $__env->startSection('content'); ?>


      <!--Start rev slider wrapper-->
      <section class="rev_slider_wrapper">
        <div id="slider1" class="rev_slider" data-version="5.0">
          <ul>
            <?php if(app()->getLocale() == 'en'): ?>
            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li data-transition="rs-20">
              <img
                src="<?php echo e(asset('storage/' . $slider->image)); ?>"
                alt=""
                width="1920"
                height="700"
                data-bgposition="top center"
                data-bgfit="cover"
                data-bgrepeat="no-repeat"
                data-bgparallax="1"
              />

              <div
                class="tp-caption tp-resizeme"
                data-x="left"
                data-hoffset="0"
                data-y="top"
                data-voffset="220"
                data-transform_idle="o:1;"
                data-transform_in="x:[-175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0.01;s:3000;e:Power3.easeOut;"
                data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"
                data-mask_in="x:[100%];y:0;s:inherit;e:inherit;"
                data-splitin="none"
                data-splitout="none"
                data-responsive_offset="on"
                data-start="1500"
              >
                <div class="slide-content-box mar-lft">
                  <?php echo $slider->titleg; ?>

                  <?php echo $slider->contentg; ?>

                 
                  <div class="button">
                    <a class="btn-style-two" href="<?php echo e(route('departments' , app()->getLocale())); ?>"><?php echo app('translator')->get('pages.departments'); ?></a>
                  </div>
                </div>
              </div>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li data-transition="rs-20">
              <img
                src="<?php echo e(asset('storage/' . $slider->image)); ?>"
                alt=""
                width="1920"
                height="700"
                data-bgposition="top center"
                data-bgfit="cover"
                data-bgrepeat="no-repeat"
                data-bgparallax="1"
              />

              <div
                class="tp-caption tp-resizeme"
                data-x="right"
                data-hoffset="0"
                data-y="top"
                data-voffset="220"
                data-transform_idle="o:1;"
                data-transform_in="x:[-175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0.01;s:3000;e:Power3.easeOut;"
                data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"
                data-mask_in="x:[100%];y:0;s:inherit;e:inherit;"
                data-splitin="none"
                data-splitout="none"
                data-responsive_offset="on"
                data-start="1500"
              >
                <div class="slide-content-box mar-lft">
                  <?php echo $slider->titleg; ?>

                  <?php echo $slider->contentg; ?>

                 
                  <div class="button">
                    <a class="btn-style-two" href="<?php echo e(route('departments' , app()->getLocale())); ?>"><?php echo app('translator')->get('pages.departments'); ?></a>
                  </div>
                </div>
              </div>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
          </ul>
        </div>
      </section>
      <!--End rev slider wrapper-->

      

      <!--Start Medical Departments area-->
      <section class="medical-departments-area">
        <div class="container">
          <div class="sec-title">
            <h1><?php echo app('translator')->get('pages.medical_departments'); ?></h1>
            <span class="border"></span>
          </div>
          <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
              <div class="medical-departments-carousel">
                <!--Start single item-->
                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="single-item text-center">
                  <div class="iocn-holder">
                    <span class="flaticon-<?php echo e($department->icon); ?>"></span>
                  </div>
                  <div class="text-holder">
                  <h3><?php echo e($department->nameg); ?></h3>
                    <p>
                      <?php echo e($department->breifg); ?>

                    </p>
                  </div>
                </div>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
              </div>
            </div>
          </div>
        </div>
      </section>
      <!--End Medical Departments area-->

      <!--Start service area-->
      <section class="service-area">
        <div class="container">
          <div class="row">
            <div class="col-md-4 fl-right">
              <div class="img-holder">
                <img src="<?php echo e(asset('storage/' . setting('site.servicesimage'))); ?>" alt="<?php echo e(__('pages.alt')); ?>" />
                
              </div>
            </div>
            <div class="col-md-8">
              <div class="text-holder">
                <!--Start tab box-->
                <div class="tab-box">
                  <div class="tab-content">
                    <!--Start single tab pane-->
                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="<?php echo e($service->id == 1 ? 'active' : ''); ?> tab-pane" id="<?php echo e($service->id); ?>">
                      <div class="inner-content">
                        <div class="sec-title">
                          <h1><?php echo app('translator')->get('pages.our_best_servicess'); ?></h1>
                          <span class="border"></span>
                        </div>
                        <div class="row">
                          <div class="col-md-6 fl-right tx-right">
                            <div class="text-box">
                              <h3><?php echo e($service->nameg); ?></h3>
                              <p>
                                <?php echo e($service->breifg); ?>

                              </p>
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="img-box tx-right">
                              <img src="<?php echo e(asset('storage/' . $service->image)); ?>" alt="<?php echo e(__('pages.alt')); ?>" />

                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!--End single tab pane-->
                   
                  </div>
                  
                  <ul class="nav nav-tabs tab-menu">
                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                    <li class="<?php echo e($service->id == 1 ? 'active' : ''); ?> fl-right">
                      <a href="#<?php echo e($service->id); ?>" data-toggle="tab">
                        <div class="img-holder" >
                          <img src="<?php echo e(asset('storage/' . $service->image)); ?>" alt="<?php echo e(__('pages.alt')); ?>" />
                          
                          <div class="overlay-style-one">
                            <div class="box">
                              <div class="content">
                                <div class="iocn-holder">
                                  <span class="flaticon-plus-symbol"></span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </a>
                    <h3><?php echo e($service->nameg); ?></h3>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                  </ul>
                </div>
                <!--End tab box-->
              </div>
            </div>
          </div>
        </div>
      </section>
      <!--End service area-->

      <!--Start team area-->
      <section class="team-area">
        <div class="container">
          <div class="sec-title">
            <h1><?php echo app('translator')->get('pages.team_of_consultunts'); ?></h1>
            <span class="border"></span>
          </div>
          <div class="row">
            <!--Start single item-->
            <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
              <div class="single-team-member">
                <div class="img-holder">
                  <img src="<?php echo e(asset('storage/' . $doctor->image)); ?>" alt="<?php echo e(__('pages.alt')); ?>" />
                  <div class="overlay-style">
                    <div class="box">
                      <div class="content">
                        <div class="top">
                          <h3> <?php echo e($doctor->nameg); ?></h3>
                          <span> <?php echo e($doctor->title); ?></span>
                        </div>
                        <span class="border"></span>
                      </div>
                    </div>
                  </div>
                  <div class="text-holder">
                    <h3> <?php echo e($doctor->nameg); ?></h3>
                          <span> <?php echo e($doctor->title); ?></span>
                  </div>
                </div>
              </div>
            </div>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
          </div>
        </div>
      </section>
      <!--End team area-->

      

      <!--Start testimonial area-->
      <section class="testimonial-area">
        <div class="container">
          <div class="sec-title mar0auto text-center">
            <h1><?php echo app('translator')->get('pages.what_clients_say'); ?></h1>
            <span class="border center-before"></span>
          </div>
          <div class="row">
            <!--Start single item-->
            <div class="col-md-12">
              <div class="testimonial-carousel">
                <!--Start single testimonial item-->
                <?php $__currentLoopData = $testemonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testemonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                <div class="single-testimonial-item text-center">
                  <div class="img-box">
                    <div class="img-holder">
                  <img src="<?php echo e(asset('storage/' . $testemonial->image)); ?>" alt="<?php echo e(__('pages.alt')); ?>" />
                  
                    </div>
                    <div class="quote-box">
                      <i class="fa fa-quote-left" aria-hidden="true"></i>
                    </div>
                  </div>
                  <div class="text-holder">
                    <p>
                      <?php echo e($testemonial->content); ?>

                    </p>
                  </div>
                  <div class="name">
                    <h3><?php echo e($testemonial->nameg); ?></h3>
                    <span><?php echo e($testemonial->title); ?></span>
                  </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
              </div>
            </div>
            <!--End single item-->
          </div>
        </div>
      </section>
      <!--End testimonial area-->

    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /root/ahmed/laravel/github/hospital/momayez/resources/views/home.blade.php ENDPATH**/ ?>