<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('page', $title); ?>


<?php $__env->startSection('content'); ?>


<!--Start contact form area-->
<section class="contact-form-area">
    <div class="container">
        <div class="sec-title">
            <h1><?php echo app('translator')->get('pages.get_job'); ?></h1>
            <span class="border"></span>
            
        </div>
        <div class="row">
            <div class="col-lg-8 col-md-7 fl-right tx-right">
                <div class="contact-form">
                    <form id="contact-form" name="contact_form" class="default-form" action="#" method="post">
                        <h2><?php echo app('translator')->get('pages.send_your_data'); ?></h2>
                        <div class="row">
                            <div class="col-md-6 fl-right">
                            <input type="text" name="form_name" value="" placeholder="<?php echo e(__('pages.your_name')); ?>" required="">
                            </div>
                            <div class="col-md-6">
                                <input type="email" name="form_email" value="" placeholder="<?php echo e(__('pages.your_email')); ?>*" required="">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12 fl-right">
                                <input type="text" name="form_phone" value="" placeholder="<?php echo e(__('pages.phone')); ?>">
                            </div>
                           
                        </div>
                        <div class="row">
                            <div class="col-md-12 mb-20">
                                <input type="file" class="fl-right rtl" name="cv" placeholder="<?php echo e(__('pages.cv')); ?>">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <input id="form_botcheck" name="form_botcheck" class="form-control" type="hidden" value="">
                                <button class="thm-btn bgclr-1" type="submit" data-loading-text="Please wait..."><?php echo app('translator')->get('pages.send'); ?></button>
                            </div>
                        </div>
                    </form>  
                </div>
            </div>
            <div class="col-lg-4 col-md-5 tx-right">
                <div class="quick-contact">
                    <div class="title">
                        <h2><?php echo app('translator')->get('pages.quick_contact'); ?></h2>
                        <p><?php echo app('translator')->get('pages.any_ques'); ?></p>
                    </div>
                    <ul class="contact-info">
                        <li>
                            <div class="icon-holder">
                                <span class="flaticon-pin"></span>
                            </div>
                            <div class="text-holder">
                                <h5><span><?php echo app('translator')->get('pages.address'); ?>:</span> 
                                    <?php if(app()->getLocale() !== 'ar'): ?>
                                    <?php echo e(setting('site.address')); ?><br />
                                    <?php echo e(setting('site.address2')); ?>

                                        
                                    <?php else: ?>
                                    <?php echo e(setting('site.addressar')); ?><br />
                                    <?php echo e(setting('site.addressar2')); ?>

                                    <?php endif; ?>
                                </h5>
                            </div>
                        </li>
                        <li>
                            <div class="icon-holder">
                                <span class="flaticon-technology"></span>
                            </div>
                            <div class="text-holder">
                                <h5><span><?php echo app('translator')->get('pages.phone'); ?>:</span> <?php echo e(setting('site.phone')); ?> &<br> <?php echo e(setting('site.ambulancephone')); ?></h5>
                            </div>
                        </li>
                        <li>
                            <div class="icon-holder">
                                <span class="flaticon-interface"></span>
                            </div>
                            <div class="text-holder">
                                <h5><span><?php echo app('translator')->get('pages.email'); ?>:</span> <?php echo e(setting('site.email')); ?></h5>
                            </div>
                        </li>
                    </ul>
                    <ul class="social-links">
                        <li>
                            <a href="<?php echo e(setting('site.facebook')); ?>"><i class="fa fa-facebook"></i></a>
                            </li>
                            <li>
                              <a href="<?php echo e(setting('site.twitter')); ?>"><i class="fa fa-twitter"></i></a>
                            </li>
                            
                            <li>
                              <a href="<?php echo e(setting('site.linkedin')); ?>"><i class="fa fa-linkedin"></i></a>
                            </li>
                    </ul>
                </div>    
            </div>
            
        </div>
    </div>
</section>
<!--End contact form area-->  


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /root/ahmed/laravel/github/hospital/momayez/resources/views/careers.blade.php ENDPATH**/ ?>