<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('page', $title); ?>


<?php $__env->startSection('content'); ?>


<!--Start team area-->
<section class="team-area doctor doctor-page-area">
    <div class="container">
        <div class="row">
            <div class="col-md-3 fl-right">
                <ul class="nav nav-tabs tab-menu">
                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <li class="<?php echo e($department->id == 1 ? 'active' : ''); ?>"><a  href="#<?php echo e($department->id); ?>" data-toggle="tab"><?php echo e($department->nameg); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>   
            </div>
            <div class="col-md-9  ">
                <div class="tab-content">
                    <!--Start single tab pane-->
                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                <div class="<?php echo e($department->id == 1 ? 'active' : ''); ?> tab-pane" id="<?php echo e($department->id); ?>">
                        <div class="row">
                            <!--Start single item-->
                            <?php
                                $doctors = \App\Models\Doctor::where('department_id' , $department->id)->get();
                            ?>
                            <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 fl-right">
                                <div class="single-team-member">
                                    <div class="img-holder">
                                        <img src="<?php echo e(asset('storage/' .$doctor->image)); ?>" alt="Awesome Image">
                                        <div class="overlay-style">
                                            <div class="box">
                                                <div class="content">
                                                    <div class="top">
                                                        <h3><?php echo e($doctor->nameg); ?></h3>
                                                        <span><?php echo e($doctor->title); ?></span>
                                                    </div>
                                                    <span class="border"></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="text-holder">
                                            <h3><?php echo e($doctor->nameg); ?></h3>
                                            <span><?php echo e($doctor->title); ?></span> 
                                        </div>    
                                    </div>
                                </div>
                            </div>
                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!--End single tab pane-->
                    
                    
                </div>
            </div>
        </div>
    </div>
</section> 
<!--End team area--> 

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /root/ahmed/laravel/github/hospital/momayez/resources/views/doctors.blade.php ENDPATH**/ ?>