<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('page', __('pages.departments')); ?>


<?php $__env->startSection('content'); ?>


<!--Start Medical Departments area-->
<section class="medical-departments-area departments-page">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12 fl-right">
                <div class="single-item text-center">
                    <div class="iocn-holder">
                        <span class="flaticon-<?php echo e($department->icon); ?>"></span>    
                    </div>
                    <div class="text-holder">
                        <h3><?php echo e($department->nameg); ?></h3>
                        <p><?php echo e($department->breifg); ?></p>
                    </div>
                </div>
            </div> 
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        </div>
       
    </div>
</section>
<!--End Medical Departments area--> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /root/ahmed/laravel/github/hospital/momayez/resources/views/departments.blade.php ENDPATH**/ ?>