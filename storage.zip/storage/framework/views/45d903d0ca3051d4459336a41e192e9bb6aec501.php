<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('page', __('pages.about')); ?>


<?php $__env->startSection('content'); ?>
<!--Start breadcrumb area-->     


<!--Start welcome area-->
<section class="welcome-area">
    <div class="container">
        <div class="row">
            <div class="col-md-6 fl-right">
                <div class="img-holder">
                    <img src="<?php echo e(asset('storage/' . setting('site.aboutimage'))); ?>" alt="Awesome Image">    
                </div>
              
            </div>
            <div class="col-md-6 tx-right">
                <div class="text-holder">
                    <div class="title">
                        <h1><?php echo app('translator')->get('pages.welcome_to'); ?></h1>
                        <p>
                            <?php if(app()->getLocale() !== 'ar'): ?>
                              <?php echo e(setting('site.about')); ?>

                            <?php else: ?>
                              <?php echo e(setting('site.aboutar')); ?>

        
                            <?php endif; ?>
                          </p>
                          <p class="mar-top">
                            <?php if(app()->getLocale() !== 'ar'): ?>
                              <?php echo e(setting('site.about2')); ?>

                            <?php else: ?>
                              <?php echo e(setting('site.aboutar2')); ?>

                            <?php endif; ?>
                          </p>   
                    </div>
                    <ul>
                        <li>
                            <div class="single-item">
                                <div class="iocn-box">
                                    <span class="flaticon-shapes"></span>
                                </div>
                                <div class="text-box">
                                    <h3><?php echo app('translator')->get('pages.our_mission'); ?></h3>
                                    <p>
                                        <?php if(app()->getLocale() !== 'ar'): ?>
                                            <?php echo e(setting('site.mission')); ?>

                                        <?php else: ?>
                                            <?php echo e(setting('site.missionar')); ?>

                    
                                        <?php endif; ?>
                                          
                                    </p>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="single-item">
                                <div class="iocn-box">
                                    <span class="flaticon-technology-2"></span>
                                </div>
                                <div class="text-box">
                                    <h3><?php echo app('translator')->get('pages.our_vison'); ?></h3>
                                    <p>
                                        <?php if(app()->getLocale() !== 'ar'): ?>
                                            <?php echo e(setting('site.vision')); ?>

                                        <?php else: ?>
                                            <?php echo e(setting('site.visionar')); ?>

                    
                                        <?php endif; ?>
                                          
                                    </p>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="single-item">
                                <div class="iocn-box">
                                    <span class="flaticon-technology-2"></span>
                                </div>
                                <div class="text-box">
                                    <h3><?php echo app('translator')->get('pages.our_values'); ?></h3>
                                    <p>
                                        <?php if(app()->getLocale() !== 'ar'): ?>
                                            <?php echo e(setting('site.values')); ?>

                                        <?php else: ?>
                                            <?php echo e(setting('site.valuesar')); ?>

                    
                                        <?php endif; ?>
                                          
                                    </p>
                                </div>
                            </div>
                        </li>
                    </ul>
                    <div class="button">
                    <a class="thm-btn bgclr-1 fl-right" href="<?php echo e(route('departments' , app()->getLocale())); ?>"><?php echo app('translator')->get('pages.departments'); ?></a>
                    </div>    
                </div>
            </div>
        </div>
    </div>    
</section>
<!--End welcome area-->



<!--Start project faq area-->
<section class="project-faq-area sec-padding">
    <div class="container">
        <div class="sec-title mar0auto text-center">
            <h1><?php echo app('translator')->get('pages.gallery_faq'); ?></h1>
            <span class="border center-before"></span>
        </div>
        <div class="row">
            <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12 fl-right">
                <div class="latest-project">
                    <!--Start single blog post-->
                    <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                    <div class="single-project-item">
                        <div class="img-holder">
                  <img src="<?php echo e(asset('storage/' . $image->image)); ?>" alt="<?php echo e($image->alt); ?>" />
                 
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                </div>    
            </div>
            <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12 tx-right">
                <div class="faq-content">
                    <div class="accordion-box">
                        <!--Start single accordion box-->
                        <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4><?php echo e($faq->questiong); ?></h4>
                            </div>
                            <div class="accord-content">
                                <p><?php echo $faq->answerg; ?></p>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!--End single accordion box--> 
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--End project faq area--> 


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /root/ahmed/laravel/github/hospital/momayez/resources/views/about.blade.php ENDPATH**/ ?>