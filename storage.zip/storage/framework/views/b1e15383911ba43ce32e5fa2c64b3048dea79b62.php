<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
        <title>
          <?php if(app()->getLocale() !== 'ar'): ?>
            <?php echo e(setting('site.title')); ?>

          <?php else: ?>
          <?php echo e(setting('site.titlear')); ?>


          <?php endif; ?>
          -
          
          <?php echo $__env->yieldContent('title'); ?></title>

    <!-- responsive meta -->
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <?php if(app()->getLocale() !== 'ar'): ?>
      <meta name="description" content="<?php echo e(setting('site.title')); ?>">
    <?php else: ?>
      <meta name="description" content="<?php echo e(setting('site.titlear')); ?>">
    <?php endif; ?>

    <!-- For IE -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <!-- master stylesheet -->
        
        <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>" />
    <!-- Responsive stylesheet -->
    <link rel="stylesheet" href="<?php echo e(asset('css/responsive.css')); ?>" />

    
    <?php if(app()->getLocale() == 'ar'): ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/rtl.css')); ?>" />

    <?php endif; ?>
    <!-- Favicon -->
    <link
      rel="apple-touch-icon"
      sizes="180x180"
      href="images/favicon/apple-touch-icon.png"
    />
    <link
      rel="icon"
      type="image/png"
      href="images/favicon/favicon-32x32.png"
      sizes="32x32"
    />
    <link
      rel="icon"
      type="image/png"
      href="images/favicon/favicon-16x16.png"
      sizes="16x16"
    />
    
    <link rel="icon" type="image/png" href="<?php echo e(asset('storage/' . setting('site.icon'))); ?>" sizes="16x16">
    <!-- Fixing Internet Explorer-->
    <!--[if lt IE 9]>
      <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
      <script src="<?php echo e(asset('js/html5shiv.js')); ?>"></script>
    <![endif]-->
  </head>
  <body>
    <div class="boxed_wrapper">
      <!--Start Preloader -->
      <div class="preloader"></div>
     
      <!--Start top bar area-->
      <section class="top-bar-area">
        <div class="container">
          <div class="row">
            <div class="col-lg-7 col-md-6 col-sm-12 col-xs-12 fl-right tx-right">
              <div class="top-left">
                <p>
                  <span class="fl-right flaticon-phone ml-left-5"></span><?php echo app('translator')->get('pages.24/7'); ?> <?php echo e(setting('site.ambulancephone')); ?>

                </p>
              </div>
            </div>
            <div class="col-lg-5 col-md-6 col-sm-12 col-xs-12 fl-left tx-left">
              <div class="top-right clearfix fl-left">
                <ul class="social-links">
                  <li>
                    <a href="<?php echo e(setting('site.fadecbook')); ?>"><i class="fa fa-facebook"></i></a>
                  </li>
                  <li>
                    <a href="<?php echo e(setting('site.twitter')); ?>"><i class="fa fa-twitter"></i></a>
                  </li>
                  
                  <li>
                    <a href="<?php echo e(setting('site.linkedin')); ?>"><i class="fa fa-linkedin"></i></a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!--End top bar area-->

      <!--Start header area-->
      <section class="header-area">
        <div class="container">
          <div class="row">
            <div class="col-lg-3 col-md-3 fl-right md-none">
              <div class="logo">
                <a href="<?php echo e(route('home' , app()->getLocale())); ?>">
                <img src="<?php echo e(asset('storage/' . setting('site.logo'))); ?>" alt="__('pages.alt')" />
                </a>
              </div>
            </div>
            <div class="col-lg-9 col-md-9 ">
              <div class="header-right ">
                <ul>
                  <li>
                    <div class="icon-holder">
                      <span class="flaticon-technology"></span>
                    </div>
                    <div class="text-holder">
                      <h4><?php echo app('translator')->get('pages.call_us'); ?></h4>
                    <span><?php echo e(setting('site.phone')); ?></span>
                    </div>
                  </li>
                  <li>
                    <div class="icon-holder">
                      <span class="flaticon-pin"></span>
                    </div>
                    <div class="text-holder">
                      <?php if(app()->getLocale() !== 'ar'): ?>
                        
                            
                        <h4><?php echo e(setting('site.address')); ?></h4>
                          <span><?php echo e(setting('site.address2')); ?></span>
                        </div>
                        <?php else: ?>
                        <h4><?php echo e(setting('site.addressar')); ?></h4>
                          <span><?php echo e(setting('site.addressar2')); ?></span>
                        </div>
                        <?php endif; ?>
                  </li>
                  <li>
                    <div class="icon-holder">
                      <span class="flaticon-agenda"></span>
                    </div>
                    <div class="text-holder">
                      <h4><?php echo app('translator')->get('pages.everyday'); ?></h4>
                      <span> <?php echo app('translator')->get('pages.24/7h'); ?></span>
                    </div>
                  </li>
                </ul>
                
              </div>
            </div>
          </div>
        </div>
      </section>
      <!--End header area-->

      <!--Start header-search  area-->
      

           <!--Start mainmenu area-->
     <section class="mainmenu-area stricky">
        <div class="container">
          <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
              <!--Start mainmenu-->
              <nav class="main-menu pull-left">
                <div class="navbar-header">
                  <button
                    type="button"
                    class="navbar-toggle"
                    data-toggle="collapse"
                    data-target=".navbar-collapse"
                  >
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                  </button>
                </div>
                <div class="navbar-collapse collapse clearfix">
                  <ul class="navigation clearfix">
                  <li class="<?php echo e(Route::currentRouteName() == 'home' ? 'current' : ''); ?>"><a href="<?php echo e(route('home' , app()->getLocale())); ?>"><?php echo app('translator')->get('pages.home'); ?></a></li>
                    <li class="<?php echo e(Route::currentRouteName() == 'about' ? 'current' : ''); ?>">
                      <a href="<?php echo e(route('about' , app()->getLocale())); ?>"><?php echo app('translator')->get('pages.about'); ?></a>
                     
                    </li>
                    <li  class="<?php echo e(Route::currentRouteName() == 'departments' ? 'current' : ''); ?>">
                      <a href="<?php echo e(route('departments' , app()->getLocale())); ?>"><?php echo app('translator')->get('pages.departments'); ?></a>
                     
                    </li>
                    
                    
                    
                    <li class="<?php echo e(Route::currentRouteName() == 'doctors' ? 'current' : ''); ?>"><a href="<?php echo e(route('doctors' , app()->getLocale())); ?>"><?php echo app('translator')->get('pages.doctors'); ?></a></li>
                    <li class="<?php echo e(Route::currentRouteName() == 'careers' ? 'current' : ''); ?>"><a href="<?php echo e(route('careers' , app()->getLocale())); ?>"><?php echo app('translator')->get('pages.careers'); ?></a></li>
                    <li class="<?php echo e(Route::currentRouteName() == 'contact' ? 'current' : ''); ?>"><a href="<?php echo e(route('contact' , app()->getLocale())); ?>"><?php echo app('translator')->get('pages.contact'); ?></a></li>
                  </ul>
                </div>
              </nav>
              <!--End mainmenu-->
              <!--Start mainmenu right box-->
              <div class="mainmenu-right-box pull-right">
                
                <div class="consultation-button">
                    <?php if(app()->getLocale() == 'en'): ?>
                    <a href="<?php echo e(route(Route::currentRouteName(), 'ar')); ?>" class="tx-left text-right">
                        <i class="fa fa-globe"></i>العربية
                      </a>
                    <?php else: ?>
                    <a href="<?php echo e(route(Route::currentRouteName(), 'en')); ?>" class="tx-left text-right">
                        <i class="fa fa-globe"></i>English
                      </a>
                    <?php endif; ?>
                   
                </div>
              </div>
              <!--End mainmenu right box-->
            </div>
          </div>
        </div>
      </section>
      <!--End mainmenu area-->
      <!--End header-search  area-->
     <?php
         $routeName = Route::currentRouteName();
     ?>
     <?php if($routeName!=='home'): ?>
     <section class="breadcrumb-area" style="background-image: url(<?php echo e(asset('storage/' . setting('site.headerimage'))); ?>);">
      <div class="container">
          <div class="row">
              <div class="col-md-12">
                  <div class="breadcrumbs">
                      <h1><?php echo $__env->yieldContent('page'); ?></h1>
                  </div>
              </div>
          </div>
      </div>
      <div class="breadcrumb-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="left pull-left">
                            <ul>
                                <li><a href="<?php echo e(route('home' , app()->getLocale())); ?>"><?php echo app('translator')->get('pages.home'); ?></a></li>
                                <li><i class="fa fa-angle-right" aria-hidden="true"></i></li>
                                <li class="active"><?php echo $__env->yieldContent('page'); ?></li>
                            </ul>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End breadcrumb area-->
     <?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>
      
      <!--Start footer area-->
      <footer class="footer-area">
        <div class="container">
          <div class="row">
            <!--Start single footer widget-->
            <div class="col-lg-3 fl-right tx-right col-md-6 col-sm-6 col-xs-12">
              <div class="single-footer-widget pd-bottom50">
                <div class="title">
                  <h3><?php echo app('translator')->get('pages.about'); ?></h3>
                  <span class="border"></span>
                </div>
                <div class="our-info">
                  <p>
                    <?php if(app()->getLocale() !== 'ar'): ?>
                      <?php echo e(setting('site.about')); ?>

                    <?php else: ?>
                      <?php echo e(setting('site.aboutar')); ?>


                    <?php endif; ?>
                  </p>
                  <p class="mar-top">
                    <?php if(app()->getLocale() !== 'ar'): ?>
                      <?php echo e(setting('site.about2')); ?>

                    <?php else: ?>
                      <?php echo e(setting('site.aboutar2')); ?>

                    <?php endif; ?>
                  </p>
                  <a href="<?php echo e(route('about' , app()->getLocale())); ?>"
                    ><?php echo app('translator')->get('pages.know_more'); ?><i
                      class="fa fa-caret-right"
                      aria-hidden="true"
                    ></i
                  ></a>
                </div>
              </div>
            </div>
            <!--End single footer widget-->
            <!--Start single footer widget-->
            <div class="col-lg-3 fl-right tx-right col-md-6 col-sm-6 col-xs-12">
              <div class="single-footer-widget pd-bottom50">
                <div class="title">
                  <h3><?php echo app('translator')->get('pages.useful_links'); ?></h3>
                  <span class="border"></span>
                </div>
                <ul class="usefull-links fl-lft">
                  <li>
                    <a href="<?php echo e(route('about' , app()->getLocale())); ?>"><?php echo app('translator')->get('pages.about'); ?></a>
                  </li>
                  <li >
                    <a href="<?php echo e(route('departments' , app()->getLocale())); ?>"><?php echo app('translator')->get('pages.departments'); ?></a>
                    
                  </li>
                  
                  
                  
                  <li><a href="<?php echo e(route('doctors' , app()->getLocale())); ?>"><?php echo app('translator')->get('pages.doctors'); ?></a></li>
                
                </ul>
                
                <ul class="usefull-links">
                  <li><a href="<?php echo e(route('careers' , app()->getLocale())); ?>"><?php echo app('translator')->get('pages.careers'); ?></a></li>
                  <li><a href="<?php echo e(route('contact' , app()->getLocale())); ?>"><?php echo app('translator')->get('pages.contact'); ?></a></li>
                </ul>


              </div>
            </div>
            <!--End single footer widget-->
            <!--Start single footer widget-->
            <div class="col-lg-3 fl-right tx-right col-md-6 col-sm-6 col-xs-12">
              <div class="single-footer-widget mar-bottom">
                <div class="title">
                  <h3><?php echo app('translator')->get('pages.contact_details'); ?></h3>
                  <span class="border"></span>
                </div>
                <ul class="footer-contact-info">
                  <li>
                    <div class="icon-holder">
                      <span class="flaticon-pin"></span>
                    </div>
                    <div class="text-holder">
                      <h5>
                        <?php if(app()->getLocale() !== 'ar'): ?>
                        <?php echo e(setting('site.address')); ?><br />
                        <?php echo e(setting('site.address2')); ?>

                            
                        <?php else: ?>
                        <?php echo e(setting('site.addressar')); ?><br />
                        <?php echo e(setting('site.addressar2')); ?>

                        <?php endif; ?>
                      </h5>
                    </div>
                  </li>
                  <li>
                    <div class="icon-holder">
                      <span class="flaticon-interface"></span>
                    </div>
                    <div class="text-holder">
                      <h5><?php echo e(setting('site.email')); ?></h5>
                    </div>
                  </li>
                  <li>
                    <div class="icon-holder">
                      <span class="flaticon-technology-1"></span>
                    </div>
                    <div class="text-holder">
                      <h5><?php echo e(setting('site.phone')); ?> & <?php echo e(setting('site.ambulancephone')); ?></h5>
                    </div>
                  </li>
                  <li>
                    <div class="icon-holder">
                      <span class="flaticon-clock"></span>
                    </div>
                    <div class="text-holder">
                      <h5><?php echo app('translator')->get('pages.everyday'); ?>: <?php echo app('translator')->get('pages.24/7h'); ?></h5>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
            <!--Start single footer widget-->
            <!--Start single footer widget-->
            <div class="col-lg-3 fl-right tx-right col-md-6 col-sm-6 col-xs-12">
              <div class="single-footer-widget clearfix">
                <div class="title">
                  <h3><?php echo app('translator')->get('pages.send_email'); ?></h3>
                  <span class="border"></span>
                </div>
                <form class="appointment-form" action="#">
                  <div class="input-box">
                    <input
                      type="text"
                      name="form_name"
                      value=""
                  placeholder="<?php echo e(__('pages.your_name')); ?>"
                      required=""
                    />
                    <div class="icon-box">
                      <i class="fa fa-user" aria-hidden="true"></i>
                    </div>
                  </div>
                  <div class="input-box">
                    <input
                      type="email"
                      name="form_email"
                      value=""
                      placeholder="<?php echo e(__('pages.your_email')); ?>"
                      required=""
                    />
                    <div class="icon-box">
                      <i class="fa fa-envelope" aria-hidden="true"></i>
                    </div>
                  </div>
                  <div class="input-box">
                    <textarea
                      name="form_message"
                      placeholder="<?php echo e(__('pages.your_msg')); ?>"
                      required=""
                      aria-required="true"
                    ></textarea>
                  </div>
                  <button type="submit"><?php echo app('translator')->get('pages.submit'); ?></button>
                </form>
              </div>
            </div>
            <!--End single footer widget-->
          </div>
        </div>
      </footer>
      <!--End footer area-->

      <!--Start footer bottom area-->
      <section class="footer-bottom-area">
        <div class="container">
          <div class="row">
            <div class="col-md-8 fl-right tx-right rtl">
              <div class="copyright-text">
                <p>
                 <?php echo app('translator')->get('pages.copyright'); ?>
                 <a target="_blank" href="http://www.esolve-eg.com">Esolve.</a>
                 <?php echo app('translator')->get('pages.powered_by'); ?>
                 <a >ImediaHouse.</a>
                </p>
              </div>
            </div>
            <div class="col-md-4">
              <ul class="footer-social-links fl-left">
                <li>
                <a href="<?php echo e(setting('site.facebook')); ?>"><i class="fa fa-facebook"></i></a>
                </li>
                <li>
                  <a href="<?php echo e(setting('site.twitter')); ?>"><i class="fa fa-twitter"></i></a>
                </li>
                
                <li>
                  <a href="<?php echo e(setting('site.linkedin')); ?>"><i class="fa fa-linkedin"></i></a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>
      <!--End footer bottom area-->
    </div>

    <!--Scroll to top-->
    <div class="scroll-to-top scroll-to-target" data-target="html">
      <span class="flaticon-triangle-inside-circle"></span>
    </div>

    <!-- main jQuery -->
    <script src="<?php echo e(asset('js/jquery-1.11.1.min.js')); ?>"></script>
    <!-- Wow Script -->
    <script src="<?php echo e(asset('js/wow.js')); ?>"></script>
    <!-- bootstrap -->
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <!-- bx slider -->
    <script src="<?php echo e(asset('js/jquery.bxslider.min.js')); ?>"></script>
    <!-- count to -->
    <script src="<?php echo e(asset('js/jquery.countTo.js')); ?>"></script>
    <!-- owl carousel -->
    <script src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>
    <!-- validate -->
    <script src="<?php echo e(asset('js/validation.js')); ?>"></script>
    <!-- mixit up -->
    <script src="<?php echo e(asset('js/jquery.mixitup.min.js')); ?>"></script>
    <!-- easing -->
    <script src="<?php echo e(asset('js/jquery.easing.min.js')); ?>"></script>
    <!-- gmap helper -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAHzPSV2jshbjI8fqnC_C4L08ffnj5EN3A"></script>
    <!--gmap script-->
    <script src="<?php echo e(asset('js/gmaps.js')); ?>"></script>
    <script src="<?php echo e(asset('js/map-helper.js')); ?>"></script>
    <!-- fancy box -->
    <script src="<?php echo e(asset('js/jquery.fancybox.pack.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.appear.js')); ?>"></script>
    <!-- isotope script-->
    <script src="<?php echo e(asset('js/isotope.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.prettyPhoto.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.bootstrap-touchspin.js')); ?>"></script>
    <!-- jQuery timepicker js -->
    <script src="<?php echo e(asset('assets/timepicker/timePicker.js')); ?>"></script>
    <!-- Bootstrap select picker js -->
    <script src="<?php echo e(asset('assets/bootstrap-sl-1.12.1/bootstrap-select.js')); ?>"></script>
    <!-- Bootstrap bootstrap touchspin js -->
    <!-- jQuery ui js -->
    <script src="<?php echo e(asset('assets/jquery-ui-1.11.4/jquery-ui.js')); ?>"></script>
    <!-- Language Switche  -->
    <script src="<?php echo e(asset('assets/language-switcher/jquery.polyglot.language.switcher.js')); ?>"></script>
    <!-- Html 5 light box script-->
    <script src="<?php echo e(asset('assets/html5lightbox/html5lightbox.js')); ?>"></script>

    <!-- revolution slider js -->
    <script src="<?php echo e(asset('assets/revolution/js/jquery.themepunch.tools.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/revolution/js/jquery.themepunch.revolution.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/revolution/js/extensions/revolution.extension.actions.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/revolution/js/extensions/revolution.extension.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/revolution/js/extensions/revolution.extension.kenburn.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/revolution/js/extensions/revolution.extension.layeranimation.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/revolution/js/extensions/revolution.extension.migration.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/revolution/js/extensions/revolution.extension.navigation.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/revolution/js/extensions/revolution.extension.parallax.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/revolution/js/extensions/revolution.extension.slideanims.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/revolution/js/extensions/revolution.extension.video.min.js')); ?>"></script>

    <!-- thm custom script -->
    <script src="<?php echo e(asset('js/custom.js')); ?>"></script>
  </body>
</html>
<?php /**PATH /root/ahmed/laravel/github/hospital/momayez/resources/views/layouts/app.blade.php ENDPATH**/ ?>